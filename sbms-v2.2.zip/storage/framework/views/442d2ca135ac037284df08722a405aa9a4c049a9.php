
<?php $__env->startSection('content'); ?>

 

<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Profile</h2>
      </div>
    </div>
  <div class="container-fluid">
    

            <section class="pt-3 mt-3">
                <div class="col-lg-12">
                    <div class="card">
                        
                      <div class="card-header">
                            <h3 class="h4 mb-3 "><?php echo e(Auth::user()->name); ?></h3>                            
                            <p class="text-sm text-gray-600 mb-0 lh-1"><?php echo e(Auth::user()->level); ?></p>
                      </div>
                      <div class="card-body pt-0">
                        <a href="<?php echo e(url('dashboard')); ?>">
                            <button class="btn btn-info" >
                                Kembali
                            </button>
                        </a>
                        <?php if(Auth::user()->username == 'guest'): ?>
                        <?php else: ?>
                        <a href="showprofile/<?php echo e(Auth::user()->id); ?>">
                            <button class="btn btn-success" >
                                Lihat Profil
                            </button>
                        </a>
                        
                        <a href="<?php echo e(url('changePassword')); ?>">
                            <button class="btn btn-warning" >
                                Ubah Password
                            </button>
                        </a>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
           
            
        </div>
    </div>

<?php $__env->stopSection(); ?>







  
<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/auth/profile.blade.php ENDPATH**/ ?>