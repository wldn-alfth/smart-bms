<!DOCTYPE html>
<html>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 'Admin' || Auth::user()->level == 'Developer'): ?>
  
<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Daftar Sensor</h2>
      </div>
    </div>
  <div class="container-fluid">
    
    <section class="pt-3 mt-3">
      <div class="container-fluid">
          <div class="row d-flex align-items-stretch">
              <div class="col-lg">
                  <!-- Sales bar chart-->
                  <div class="card">
                      <div class="card-body">
                        <h3>Daftar Energi</h3>
                        <?php if(Auth::user()->level == 'Developer'): ?>
                        <div class="d-flex justify-content-end">
                            <a class="btn btn-success" href="daftar-Panel-create">Tambah</a>
                        </div>
                        <?php endif; ?>
                          <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                              
                              </div>
                      
                          <?php if($message = Session::get('succes')): ?>
                          <div class="alert alert-success">
                              <p><?php echo e($message); ?></p>
                          </div>
                          <?php endif; ?>
                      
                          <table class="table table-bordered">
                            <tr>
                                <th class="text-center" width="80px">No</th>
                                <th class="text-center">Nama</th>
                                <th class="text-center" width="200px">Action</th>
                            </tr>
                            <?php $__currentLoopData = $energy_panel_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_panel_masters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e(++$i); ?></td>
                                <td>Panel Master</td>
                                <td class="text-center">
                                        <a class="btn btn-info btn-sm" href="showPanelMasterList/<?php echo e($energy_panel_masters->id); ?>">API</a>
                                        <?php if(Auth::user()->level == 'Developer'): ?>
                                        <a class="btn btn-primary btn-sm" href="#">Edit</a>
                                        <a href="#"  class="btn btn-danger btn-sm">Delete</a>
                                        <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $energy_outlet_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_outlet_masters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e(++$i); ?></td>
                                <td>Outlet Master</td>
                                <td class="text-center">
                                        <a class="btn btn-info btn-sm" href="showOutletMasterList/<?php echo e($energy_outlet_masters->id); ?>">API</a>
                                        <?php if(Auth::user()->level == 'Developer'): ?>
                                        <a class="btn btn-primary btn-sm" href="#">Edit</a>
                                        <a href="#" class="btn btn-danger btn-sm">Delete</a>
                                        <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $energy_panel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_panels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e(++$i); ?></td>
                                <td><?php echo e($energy_panels->nama); ?></td>
                                <td class="text-center">
                                        <a class="btn btn-info btn-sm" href="showPanelList/<?php echo e($energy_panels->id); ?>">API</a>
                                        <?php if(Auth::user()->level == 'Developer'): ?>
                                        <a class="btn btn-primary btn-sm" href="daftar-Panel-edit/<?php echo e($energy_panels->id); ?>">Edit</a>
                                        <a href="deletePanelList/<?php echo e($energy_panels->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                        <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                      
                          

                          </div>
                      </div>
                  </div>
              </div>
          </div>
      
  </section>

      <section class="pt-0 mt-0">
            <div class="container-fluid">
                <div class="row d-flex align-items-stretch">
                    <div class="col-lg">
                        <!-- Sales bar chart-->
                        <div class="card">
                            <div class="card-body">
                              <h3>Daftar Outlet</h3>
                              <?php if(Auth::user()->level == 'Developer'): ?>
                              <div class="d-flex justify-content-end">
                                  <a class="btn btn-success" href="daftar-Outlet-create">Tambah</a>
                              </div>
                              <?php endif; ?>
                                <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                    
                                    </div>
                            
                                <?php if($message = Session::get('succes')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e($message); ?></p>
                                </div>
                                <?php endif; ?>
                            
                                <table class="table table-bordered">
                                    <tr>
                                        <th class="text-center" width="80px">No</th>
                                        <th class="text-center">Nama</th>
                                        <th class="text-center" width="200px">Action</th>
                                    </tr>
                                    <?php $__currentLoopData = $energy_outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_outlets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e(++$j); ?></td>
                                        <td><?php echo e($energy_outlets->nama); ?></td>
                                        <td class="text-center">
                                                <a class="btn btn-info btn-sm" href="showOutletList/<?php echo e($energy_outlets->id); ?>">API</a>
                                                <?php if(Auth::user()->level == 'Developer'): ?>
                                                <a class="btn btn-primary btn-sm" href="daftar-Outlet-edit/<?php echo e($energy_outlets->id); ?>">Edit</a>
                                                <a href="deleteOutletList/<?php echo e($energy_outlets->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                                <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            
                               

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>

        <section class="pt-0 mt-0">
          <div class="container-fluid">
              <div class="row d-flex align-items-stretch gy-4">
                  <div class="col-lg">
                      <!-- Sales bar chart-->
                      <div class="card">
                          <div class="card-body">
                            <h3>Daftar Lampu</h3>
                            <?php if(Auth::user()->level == 'Developer'): ?>
                            <div class="d-flex justify-content-end">
                                <a class="btn btn-success" href="daftar-light-create">Tambah</a>
                            </div>
                            <?php endif; ?>
                              <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                  
                                  </div>
                          
                              <?php if($message = Session::get('succes')): ?>
                              <div class="alert alert-success">
                                  <p><?php echo e($message); ?></p>
                              </div>
                              <?php endif; ?>
                          
                              <table class="table table-bordered">
                                <tr>
                                    <th class="text-center" width="80px">No</th>
                                    <th class="text-center">Nama</th>
                                    <th class="text-center" width="200px">Action</th>
                                </tr>
                                <?php $__currentLoopData = $light; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lights): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e(++$k); ?></td>
                                    <td><?php echo e($lights->nama); ?></td>
                                    <td class="text-center">
                                            <a class="btn btn-info btn-sm" href="showLightList/<?php echo e($lights->id); ?>">API</a>
                                            <?php if(Auth::user()->level == 'Developer'): ?>
                                            <a class="btn btn-primary btn-sm" href="daftar-light-edit/<?php echo e($lights->id); ?>">Edit</a>
                                            <a href="deleteLightList/<?php echo e($lights->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                            <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                          
                              </div>
                          </div>
                      </div>
                  </div>
              </div>          
      </section>
      <section class="pt-0 mt-0">
        <div class="container-fluid">
            <div class="row d-flex align-items-stretch gy-4">
                <div class="col-lg">
                    <!-- Sales bar chart-->
                    <div class="card">
                        <div class="card-body">
                          <h3>Daftar Lampu Dimmer</h3>
                          <?php if(Auth::user()->level == 'Developer'): ?>
                          <div class="d-flex justify-content-end">
                              <a class="btn btn-success" href="daftar-lightDimmer-create">Tambah</a>
                          </div>
                          <?php endif; ?>
                            <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                
                                </div>
                        
                            <?php if($message = Session::get('succes')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                            <?php endif; ?>
                        
                            <table class="table table-bordered">
                              <tr>
                                  <th class="text-center" width="80px">No</th>
                                  <th class="text-center">Nama</th>
                                  <th class="text-center" width="200px">Action</th>
                              </tr>
                              <?php $__currentLoopData = $lightdimmer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lightdimmers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td class="text-center"><?php echo e(++$l); ?></td>
                                  <td><?php echo e($lightdimmers->nama); ?></td>
                                  <td class="text-center">
                                          <a class="btn btn-info btn-sm" href="showLightDimmerList/<?php echo e($lightdimmers->id); ?>">API</a>
                                          <?php if(Auth::user()->level == 'Developer'): ?>
                                          <a class="btn btn-primary btn-sm" href="daftar-lightDimmer-edit/<?php echo e($lightdimmers->id); ?>">Edit</a>
                                          <a href="deleteLightDimmerList/<?php echo e($lightdimmers->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                          <?php endif; ?>
                                  </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    </section>
      <section class="pt-0 mt-0">
        <div class="container-fluid">
            <div class="row d-flex align-items-stretch">
                <div class="col-lg">
                    <!-- Sales bar chart-->
                    <div class="card">
                        <div class="card-body">
                          <h3>Daftar Camera</h3>
                          <?php if(Auth::user()->level == 'Developer'): ?>
                          <div class="d-flex justify-content-end">
                              <a class="btn btn-success" href="daftar-Camera-create">Tambah</a>
                          </div>
                          <?php endif; ?>
                            <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                
                                </div>
                        
                            <?php if($message = Session::get('succes')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                            <?php endif; ?>
                        
                            <table class="table table-bordered">
                                <tr>
                                    <th class="text-center" width="80px">No</th>
                                    <th class="text-center">Nama</th>
                                    <th class="text-center">IP/Link</th>
                                    <?php if(Auth::user()->level == 'Developer'): ?>
                                    <th class="text-center" width="200px">Action</th>
                                    <?php endif; ?>
                                </tr>
                                <?php $__currentLoopData = $camera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cameras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e(++$n); ?></td>
                                    <td><?php echo e($cameras->nama); ?></td>
                                    <td><?php echo e($cameras->link); ?></td>
                                    <?php if(Auth::user()->level == 'Developer'): ?>
                                    <td class="text-center">
                                       
                                            <a class="btn btn-primary btn-sm" href="daftar-Camera-edit/<?php echo e($cameras->id); ?>">Edit</a>
                                            <a href="deleteCameraList/<?php echo e($cameras->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                        
                                    </td>
                                    <?php endif; ?> 
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        
                           

                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <section class="pt-0 mt-0">
        <div class="container-fluid">
            <div class="row d-flex align-items-stretch">
                <div class="col-lg">
                    <!-- Sales bar chart-->
                    <div class="card">
                        <div class="card-body">
                          <h3>Daftar Fire Alarm</h3>
                          <?php if(Auth::user()->level == 'Developer'): ?>
                          <div class="d-flex justify-content-end">
                              <a class="btn btn-success" href="daftar-FireAlarm-create">Tambah</a>
                          </div>
                          <?php endif; ?>
                            <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                
                                </div>
                        
                            <?php if($message = Session::get('succes')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                            <?php endif; ?>
                        
                            <table class="table table-bordered">
                                <tr>
                                    <th class="text-center" width="80px">No</th>
                                    <th class="text-center">Nama</th>
                                    <th class="text-center" width="200px">Action</th>
                                </tr>
                                <?php $__currentLoopData = $firealarm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firealarms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e(++$m); ?></td>
                                    <td><?php echo e($firealarms->nama); ?></td>
                                    <td class="text-center">
                                            <a class="btn btn-info btn-sm" href="showFireAlarmList/<?php echo e($firealarms->id); ?>">API</a>
                                            <?php if(Auth::user()->level == 'Developer'): ?>
                                            <a class="btn btn-primary btn-sm" href="daftar-FireAlarm-edit/<?php echo e($firealarms->id); ?>">Edit</a>
                                            <a href="deleteFireAlarmList/<?php echo e($firealarms->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                            <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        
                           

                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <section class="pt-0 mt-0">
        <div class="container-fluid">
            <div class="row d-flex align-items-stretch">
                <div class="col-lg">
                    <!-- Sales bar chart-->
                    <div class="card">
                        <div class="card-body">
                          <h3>Daftar DHT</h3>
                          <?php if(Auth::user()->level == 'Developer'): ?>
                          <div class="d-flex justify-content-end">
                              <a class="btn btn-success" href="daftar-Dhtx-create">Tambah</a>
                          </div>
                          <?php endif; ?>
                            <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                
                                </div>
                        
                            <?php if($message = Session::get('succes')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e($message); ?></p>
                            </div>
                            <?php endif; ?>
                        
                            <table class="table table-bordered">
                                <tr>
                                    <th class="text-center" width="80px">No</th>
                                    <th class="text-center" width="120px">ID DHT</th>
                                    <th class="text-center">Nama</th>
                                    <th class="text-center" width="140px">Tampilkan</th>
                                    <th class="text-center" width="200px">Action</th>
                                </tr>
                                <tr>
                                    <td class="text-center"><?php echo e(++$o); ?></td>
                                    <td class="text-center">DHT0</td>
                                    <td>Sensor Utama</td>
                                    <td class="text-center">
                                                                               
                                    </td>
                                    <td class="text-center">
                                            <a class="btn btn-info btn-sm" href="showdhtapi">API</a>
                                            <?php if(Auth::user()->level == 'Developer'): ?>
                                            <a class="btn btn-primary btn-sm" href="#">Edit</a>
                                            <a href="#" class="btn btn-danger btn-sm">Delete</a>
                                            <?php endif; ?>
                                    </td>
                                </tr>
                                <?php $__currentLoopData = $dhtx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dhtxs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e(++$o); ?></td>
                                    <td class="text-center"><?php echo e($dhtxs->id_nama); ?></td>
                                    <td><?php echo e($dhtxs->nama); ?></td>
                                    <td class="text-center">
                                        <?php if($dhtxs->status==1): ?>
                                        <label class="switch">
                                            <input type="checkbox" class="custom-control-input" id="customSwitch2" checked>
                                            <a href="<?php echo e(url('daftar-Dhtx-status/'.$dhtxs->id)); ?>" class="slider round" ></a>
                                        </label>
                                        <?php else: ?>
                                        <label class="switch">
                                            <input type="checkbox" class="custom-control-input" id="customSwitch2" disabled>
                                            <a href="<?php echo e(url('daftar-Dhtx-status/'.$dhtxs->id)); ?>" class="slider round" ></a>
                                        </label>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                            <a class="btn btn-info btn-sm" href="showDhtxList/<?php echo e($dhtxs->id); ?>">API</a>
                                            <?php if(Auth::user()->level == 'Developer'): ?>
                                            <a class="btn btn-primary btn-sm" href="daftar-Dhtx-edit/<?php echo e($dhtxs->id); ?>">Edit</a>
                                            <a href="deleteDhtxList/<?php echo e($dhtxs->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                            <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    



      
    </div>
</div>

<?php else: ?>
<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Akses Ditolak</h2>
      </div>
    </div>
  <div class="container-fluid">
        <section class="pt-3 mt-3">
                    <div class="container-fluid">
                        <div class="row d-flex align-items-stretch">
                            <div class="col-lg">
                                <!-- Sales bar chart-->
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                            <h3 class="h4 mb-3 text-white">Akses Menuju Laman Ditolak</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </section>
        
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/admin/sensorlist.blade.php ENDPATH**/ ?>