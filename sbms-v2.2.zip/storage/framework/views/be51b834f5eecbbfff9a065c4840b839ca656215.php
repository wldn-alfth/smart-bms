
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Dashboard</h2>
      </div>
    </div>
  <div class="container-fluid">
    
            <section class="mt-3">
                <div class="container-fluid">
                    <div class="row gy-4">
                        <div class="col-md-3 col-sm-6">
                            <div class="card mb-0">
                                <div class="card-body">
                                    <div class="d-flex align-items-end justify-content-between mb-2">
                                        <div class="me-2">
                                             <svg class="svg-icon svg-icon-sm svg-icon-heavy text-gray-600 mb-2">
                        <use xlink:href="#user-1"> </use>
                      </svg>
                                            <p class="text-sm text-uppercase text-gray-600 lh-1 mb-0">Energy Usage</p>
                                        </div>
                                        <p class="text-xxl lh-1 mb-0 text-dash-color-1">1.2</p>
                                    </div>
                                    <div class="progress" style="height: 3px">
                                        <div class="progress-bar bg-dash-color-1" role="progressbar" style="width: 30%"
                                            aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="card mb-0">
                                <div class="card-body">
                                    <div class="d-flex align-items-end justify-content-between mb-2">
                                        <div class="me-2">
                                             <svg class="svg-icon svg-icon-sm svg-icon-heavy text-gray-600 mb-2">
                        <use xlink:href="#stack-1"> </use>
                      </svg> 
                                            <p class="text-sm text-uppercase text-gray-600 lh-1 mb-0">Current Temperature</p>
                                        </div>
                                        <?php $__empty_1 = true; $__currentLoopData = $temperature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            
                                       
                                        <p class="text-xxl lh-1 mb-0 text-dash-color-3"><?php echo e($item->temperature); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                                        <?php endif; ?>

                                    </div>
                                    <div class="progress" style="height: 3px">
                                        <div class="progress-bar bg-dash-color-3" role="progressbar" style="width: 70%"
                                            aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="card mb-0">
                                <div class="card-body">
                                    <div class="d-flex align-items-end justify-content-between mb-2">
                                        <div class="me-2">
                                             <svg class="svg-icon svg-icon-sm svg-icon-heavy text-gray-600 mb-2">
                        <use xlink:href="#survey-1"> </use>
                      </svg> 
                                            <p class="text-sm text-uppercase text-gray-600 lh-1 mb-0">Current Humidity</p>
                                        </div>
                                        <?php $__currentLoopData = $humidity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                        
                                        <p class="text-xxl lh-1 mb-0 text-dash-color-2"><?php echo e($item->humidity); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="progress" style="height: 3px">
                                        <div class="progress-bar bg-dash-color-2" role="progressbar" style="width: 55%"
                                            aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="card mb-0">
                                <div class="card-body">
                                    <?php $__currentLoopData = $fire; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <?php if($item->status==0): ?>
                                    <div class="d-flex align-items-end justify-content-between mb-2">
                                        <div class="me-2">
                                            <svg class="svg-icon svg-icon-sm svg-icon-heavy text-gray-600 mb-2">
                                                    <use xlink:href="#paper-stack-1"> </use>
                                            </svg>            
                                            <p class="text-sm text-uppercase text-gray-600 lh-1 mb-0">Fire Alarm</p>
                                        </div>
                                        <p class="text-xxl lh-1 mb-0 text-success">OK</p>
                                        
                                    </div>
                                    <div class="progress" style="height: 3px">
                                        <div class="progress-bar" role="progressbar"
                                            style="width: 100%; background-color: #28a745;" aria-valuenow="80"
                                            aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <?php else: ?>
                                    <div class="d-flex align-items-end justify-content-between mb-2">
                                        <div class="me-2">
                                            <svg class="svg-icon svg-icon-sm svg-icon-heavy text-gray-600 mb-2">
                                                    <use xlink:href="#paper-stack-1"> </use>
                                            </svg>            
                                            <p class="text-sm text-uppercase text-gray-600 lh-1 mb-0">Fire Alarm</p>
                                        </div>
                                        <p class="text-xxl lh-1 mb-0 text-danger">⚠</p>
                                        
                                    </div>
                                    <div class="progress" style="height: 3px">
                                        <div class="progress-bar" role="progressbar"
                                            style="width: 100%; background-color: #a72828;" aria-valuenow="80"
                                            aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="pt-0">
                <div class="container-fluid">
                    <div class="row d-flex align-items-stretch gy-4">
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                
                                <div class="card-body"> 
                                    <h3 class="h4 mb-3">Energy Usage</h3>
                                    <!-- <p class="text-sm fw-light">Lorem ipsum dolor sit</p> -->
                                    <div class="row align-items-center mb-0">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_todays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php $__currentLoopData = $energy_cost_delay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_cost_delays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-1">
                                                <?php
                                                    echo number_format((float)($energy_todays/(3600/$energy_cost_delays)),2,'.','');
                                                ?>
                                            </p>
                                            <p>Today</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                        <?php $__currentLoopData = $energy_cost_delay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_cost_delays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-1">
                                                <?php
                                                    echo number_format((float)($energy_months/(3600/$energy_cost_delays)),2,'.','');
                                                ?>
                                            </p>
                                            <p>This Month</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        
                                        
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3">This Month Cost</h3>
                                    <div class="row align-items-end">
                                        <?php $__currentLoopData = $energy_cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_costs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $energy_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-12">
                                            <p class="text-xl fw-light mb-0 text-info">
                                                <?php
                                                echo number_format($energy_costs*$energy_months);
                                                ?>
                                            </p>
                                            <p>IDR</p>
                                        </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3" href="<?php echo e(url('camera')); ?>">Camera</h3>
                                    <div class="row align-items-center">
                                        
                                        <div class="col-lg ">
                                            <a img href="<?php echo e(url('camera')); ?>">
                                            <img src="img/stock/stock_cam.jpeg" alt="cam" width="200px" height="90px">
                                            </a>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Hidden section for chart canvas -->
            <section hidden>
                <div class="container-fluid">
                    <canvas id="salesBarChart2"></canvas>
                    <canvas id="pieChartHome1"></canvas>
                    <canvas id="pieChartHome2"></canvas>
                    <canvas id="pieChartHome3"></canvas>
                    <canvas id="barChartExample1"></canvas>
                    <canvas id="barChartExample2"></canvas>
                    <canvas id="lineChart"></canvas>
                    <canvas id="lineChart1"></canvas>
                </div>
            </section>
        </div>
    </div>
    
    <script>
        // ------------------------------------------------------- //
        //   Inject SVG Sprite - 
        //   see more here 
        //   https://css-tricks.com/ajaxing-svg-sprite/
        // ------------------------------------------------------ //
        function injectSvgSprite(path) {

            var ajax = new XMLHttpRequest();
            ajax.open("GET", path, true);
            ajax.send();
            ajax.onload = function (e) {
                var div = document.createElement("div");
                div.className = 'd-none';
                div.innerHTML = ajax.responseText;
                document.body.insertBefore(div, document.body.childNodes[0]);
            }
        }
        // this is set to BootstrapTemple website as you cannot 
        // inject local SVG sprite (using only 'icons/orion-svg-sprite.svg' path)
        // while using file:// protocol
        // pls don't forget to change to your domain :)
        injectSvgSprite('https://bootstraptemple.com/files/icons/orion-svg-sprite.svg');

    </script>
    <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</body>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/dashboard.blade.php ENDPATH**/ ?>