
<?php $__env->startSection('content'); ?>

 

<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Integrated System</h2>
      </div>
    </div>
<div class="container-fluid">
 
  <section class="pt-3 mt-3">
    <?php if(Auth::user()->level == 'Admin' || Auth::user()->level == 'Developer'): ?>
    <div class="container-fluid">
        <div class="row d-flex align-items-stretch gy-4">
            <div class="col-lg">
                <!-- Sales bar chart-->
                <div class="card">
                    <div class="card-body">
                       
                        <a class="btn btn-success" href="daftar-integratedsystem-create">Tambah</a>
                                          
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</section>

  <?php $__currentLoopData = $integrated_system; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $integrated_systems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <section class="pt-0 mt-0">
    <div class="container-fluid">
        <div class="row d-flex align-items-stretch gy-4">
            <div class="col-lg">
                <!-- Sales bar chart-->
                <div class="card">
                    <div class="card-body">
                        <h2 class="h4 mb-2 text-primary"><a href="<?php echo e($integrated_systems->link); ?>"><?php echo e($integrated_systems->nama); ?></a></h2>
                        <div class="row d-flex justify-content-center pt-0">
                            
                              <p class="text text-break text-start fw-light mb-2 "><?php echo e($integrated_systems->deskripsi); ?></p><span>
                            
                        </div>
                        <a class="btn btn-info btn-sm" href="<?php echo e($integrated_systems->link); ?>">Go</a>
                        <?php if(Auth::user()->level == 'Admin' || Auth::user()->level == 'Developer'): ?>
                        <a class="btn btn-primary btn-sm" href="daftar-integratedsystem-edit/<?php echo e($integrated_systems->id); ?>">Edit</a>
                        <a href="deleteintegratedsystemList/<?php echo e($integrated_systems->id); ?>" class="btn btn-danger btn-sm">Delete</a>
                        <?php endif; ?>                     
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
</div>
</div>

<?php $__env->stopSection(); ?>







  
<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/integratedsystem.blade.php ENDPATH**/ ?>