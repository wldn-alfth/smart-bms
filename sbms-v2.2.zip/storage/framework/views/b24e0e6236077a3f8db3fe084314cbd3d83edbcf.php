
<?php $__env->startSection('content'); ?>

<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Pin Point</h2>
      </div>
    </div>
  <div class="container-fluid">

    <section class="pt-3 mt-3">
        <div class="container-fluid">
            <div class="row d-flex align-items-stretch gy-4">
                <div class="col-lg">
                    <!-- Sales bar chart-->
                    <div class="card">
                        <div class="card-body justify-content-center">                            
                            <div id="containment-wrapper"> 
                                <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
                                <?php $__currentLoopData = $light; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lights): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="draggable" class="ui-widget-content draggable" style="position: absolute; left: <?php echo e($lights->xpos); ?>; top: <?php echo e($lights->ypos); ?>;">
                                    <a  href="<?php echo e(url('light')); ?>"> 
                                    <img class="img-fluid" src="<?php echo e(asset('img/icon/light.png')); ?>" alt="...">
                                    <span class="d-flex justify-content-center"><?php echo e($lights->nama); ?></span></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $lightdimmer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lightdimmers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="draggable" class="ui-widget-content draggable" style="position: absolute; left: <?php echo e($lightdimmers->xpos); ?>; top: <?php echo e($lightdimmers->ypos); ?>;">
                                    <a  href="<?php echo e(url('light')); ?>"> 
                                    <img class="img-fluid" src="<?php echo e(asset('img/icon/dimmer.png')); ?>" alt="...">
                                    <?php echo e($lightdimmers->nama); ?></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $energypanelmaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energypanelmasters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="draggable" class=" ui-widget-content draggable" style="position: absolute; left: <?php echo e($energypanelmasters->xpos); ?>; top: <?php echo e($energypanelmasters->ypos); ?>;">
                                    <a href="<?php echo e(url('monitor')); ?>"> 
                                    <img class="img-fluid" src="<?php echo e(asset('img/icon/panel.png')); ?>" alt="...">
                                    <span class="d-flex justify-content-center"><?php echo e($energypanelmasters->nama); ?></span></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $firealarm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firealarms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="draggable" class=" ui-widget-content draggable" style="position: absolute; left: <?php echo e($firealarms->xpos); ?>; top: <?php echo e($firealarms->ypos); ?>;">
                                    <a href="<?php echo e(url('fire-alarm')); ?>"> 
                                    <img class="img-fluid" src="<?php echo e(asset('img/icon/fire.png')); ?>" alt="...">
                                    <span class="d-flex justify-content-center"><?php echo e($firealarms->nama); ?></span></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $camera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cameras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="draggable" class=" ui-widget-content draggable" style="position: absolute; left: <?php echo e($cameras->xpos); ?>; top: <?php echo e($cameras->ypos); ?>;">
                                    <a href="<?php echo e(url('camera')); ?>"> 
                                    <img class="img-fluid" src="<?php echo e(asset('img/icon/cctv.png')); ?>" alt="...">
                                    <span class="d-flex justify-content-center"><?php echo e($cameras->nama); ?></span></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $dht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dhts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="draggable" class=" ui-widget-content draggable" style="position: absolute; left: <?php echo e($dhts->xpos); ?>; top: <?php echo e($dhts->ypos); ?>;">
                                    <a href="<?php echo e(url('temperature')); ?>"> 
                                    <img class="img-fluid" src="<?php echo e(asset('img/icon/dht.png')); ?>" alt="...">
                                    <span class="d-flex justify-content-center"><?php echo e($dhts->nama); ?></span></a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                            </div>
                            
                        </div>
                        <?php if(Auth::user()->level == 'Developer'): ?>
                        <div class="d-flex justify-content-center mb-3">
                                <a class="btn btn-primary" href="pinpointset">Setting</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

            
    </div>
</div>

    <script>
        // ------------------------------------------------------- //
        //   Inject SVG Sprite - 
        //   see more here 
        //   https://css-tricks.com/ajaxing-svg-sprite/
        // ------------------------------------------------------ //
        function injectSvgSprite(path) {

            var ajax = new XMLHttpRequest();
            ajax.open("GET", path, true);
            ajax.send();
            ajax.onload = function (e) {
                var div = document.createElement("div");
                div.className = 'd-none';
                div.innerHTML = ajax.responseText;
                document.body.insertBefore(div, document.body.childNodes[0]);
            }
        }
        // this is set to BootstrapTemple website as you cannot 
        // inject local SVG sprite (using only 'icons/orion-svg-sprite.svg' path)
        // while using file:// protocol
        // pls don't forget to change to your domain :)
        injectSvgSprite('https://bootstraptemple.com/files/icons/orion-svg-sprite.svg');

    </script>
    <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<?php if(Auth::user()->level == 'Developer'): ?>
<script type="text/javascript">
function myFunction() {
    var x = document.getElementById("btn1").value;
    var y = document.getElementById("btn2").value;
  document.getElementById("boxs").style.left = x;
  document.getElementById("boxs").style.top = y;
}      
</script>
<script type="text/javascript">
var coordinates = function(element) {
                    element = $(element);
                    var top = element.position().top;
                    var left = element.position().left;
                    $('#results').text(''+'X: ' + left + ' ' + 'Y: ' + top);
                    }

                    
                $('#boxs').draggable({
                   
                    containment: "#containment-wrapper",
                    stop: function() {
                        coordinates('#boxs');
                    }
                });
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/pin-point3show.blade.php ENDPATH**/ ?>