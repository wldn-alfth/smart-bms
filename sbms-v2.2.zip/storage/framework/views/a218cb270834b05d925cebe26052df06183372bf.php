
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Monitor </h2>
      </div>
    </div>
  <div class="container-fluid">

            <section class="mt-3">
                <div class="container-fluid">
                    <div class="row gy-4">
                        <div class="col-md-6 col-sm-6">
                            <div class="card mb-0">
                                <div class="card-body">
                                    <div class="d-flex align-items-end justify-content-between mb-2">
                                        <div class="me-2">
                                            <p class="text-sm text-uppercase text-gray-600 lh-1 mb-0">Current Usage</p>
                                        </div>
                                        <?php $__empty_1 = true; $__currentLoopData = $energies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ener): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <p class="text-xxl lh-1 mb-0 text-success"><?php echo e($ener -> active_power); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="progress" style="height: 3px">
                                        <div class="progress-bar" role="progressbar" style="width: 30%; background-color: #28a745;"
                                            aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="card mb-0">
                                <div class="card-body">
                                    <div class="d-flex align-items-end justify-content-between mb-2">
                                        <div class="me-2">
                                            <p class="text-sm text-uppercase text-gray-600 lh-1 mb-0">Electricity Price</p>
                                        </div>
                                        <?php $__currentLoopData = $energy_cost_pokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_costs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="text-xxl lh-1 mb-0 text-success">Rp. <?php echo number_format($energy_costs); ?></p>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="progress" style="height: 3px">
                                        <div class="progress-bar" style="width: 75%; background-color: #28a745;" role="progressbar"
                                            aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
             
            <section class="mt-0 pt-0">
                <div class="container-fluid">
                    <div class="row d-flex align-items-stretch gy-4">
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Energy Usage</h3>
                                    <!-- <p class="text-sm fw-light">Lorem ipsum dolor sit</p> -->
                                    <div class="row align-items-center mb-0">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_todays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php $__currentLoopData = $energy_cost_delay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_cost_delays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-1">
                                                <?php
                                                    echo number_format((float)($energy_todays/(3600/$energy_cost_delays)),2,'.','');
                                                ?>
                                            </p>
                                            <p>Today</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php $__currentLoopData = $energy_cost_delay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_cost_delays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-1">
                                                <?php
                                                    echo number_format((float)($energy_months/(3600/$energy_cost_delays)),2,'.','');
                                                ?>
                                            </p>
                                            <p>This Month</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3">This Month Cost</h3>
                                    <div class="row align-items-end">
                                        <?php $__currentLoopData = $energy_cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_costs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $energy_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-12">
                                            <p class="text-xl fw-light mb-0 text-info">
                                                <?php
                                                echo number_format($energy_costs*$energy_months);
                                                ?>
                                            </p>
                                            <p>IDR</p>
                                        </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Previous Month Cost</h3>
                                    <div class="row align-items-end">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy_submonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_submonths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-12">
                                            <p class="text-xl fw-light mb-0 text-warning">
                                                <?php
                                                echo number_format($energy_costs*$energy_submonths);
                                                ?>
                                            </p>
                                            <p>IDR</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                       
                                      
                                    </div>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </section>
            <section class="pt-0 mt-0">
                <div class="container-fluid">
                    <div class="row d-flex align-items-stretch gy-4">
                        <div class="col-lg">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <div class="row d-flex justify-content-center pt-3">
                                        <h3 class="h4 mb-3">Status</h3>
                                         <div class="row align-items-end">
                                            <?php $__currentLoopData = $energy_panel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_panels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-lg-6">
                                                        <p class="text-xl fw-light mb-0 text-info"><?php echo e($energy_panels->nama); ?></p><span>
                                                    </div> 
                                                    <?php if($energy_panels->status==1): ?>
                                                    <div class="col-lg-6">
                                                        <p class="text-xl fw-light mb-0 text-end text-success">Online</p><span>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="col-lg-6">
                                                        <p class="text-xl fw-light mb-0 text-end text-dash-color-3">Offline</p><span>
                                                    </div>
                                                    <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $energy_outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_outlets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-lg-6">
                                                        <p class="text-xl fw-light mb-0 text-info"><?php echo e($energy_outlets->nama); ?></p><span>
                                                    </div> 
                                                    <?php if($energy_outlets->status==1): ?>
                                                    <div class="col-lg-6">
                                                        <p class="text-xl fw-light mb-0 text-end text-success">Online</p><span>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="col-lg-6">
                                                        <p class="text-xl fw-light mb-0 text-end text-dash-color-3">Offline</p><span>
                                                    </div>
                                                    <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php if(Auth::user()->level == 'Admin' || Auth::user()->level == 'Developer'): ?>
            <section class="mt-3 pt-0">
                <div class="container-fluid">
                    <div class="row d-flex align-items-stretch gy-4">
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Tegangan</h3>
                                    <!-- <p class="text-sm fw-light">Lorem ipsum dolor sit</p> -->
                                    <div class="row align-items-center mb-0">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-1"><?php echo e($energies->tegangan); ?></p>
                                            <p>Volt</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-1"><?php echo e($energies2->tegangan); ?></p>
                                            <p>Volt</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Arus</h3>
                                    <div class="row align-items-end">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-info"><?php echo e($energies->arus); ?></p>
                                            <p>Node 1</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-info"><?php echo e($energies2->arus); ?></p>
                                            <p>Node 2</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Frekuensi</h3>
                                    <div class="row align-items-end">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-warning"><?php echo e($energies->frekuensi); ?></p>
                                            <p>Node 1</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-warning"><?php echo e($energies2->frekuensi); ?></p>
                                            <p>Node 2</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </section>
            <section class="pt-0">
                <div class="container-fluid">
                    <div class="row d-flex align-items-stretch gy-4">
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Active Power</h3>
                                    <!-- <p class="text-sm fw-light">Lorem ipsum dolor sit</p> -->
                                    <div class="row align-items-center mb-0">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-2"><?php echo e($energies->active_power); ?></p>
                                            <p>Node 1</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-dash-color-2"><?php echo e($energies2->active_power); ?></p>
                                            <p>Node 2</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Reactive Power</h3>
                                    <div class="row align-items-end">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-info"><?php echo e($energies->reactive_power); ?></p>
                                            <p>Node 1</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-info"><?php echo e($energies2->reactive_power); ?></p>
                                            <p>Node 2</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <h3 class="h4 mb-3">Apparent Power</h3>
                                    <div class="row align-items-end">
                                        <?php $__empty_1 = true; $__currentLoopData = $energy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-warning"><?php echo e($energies->apparent_power); ?></p>
                                            <p>Node 1</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $energy2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energies2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                        <div class="col-lg-6">
                                            <p class="text-xl fw-light mb-0 text-warning"><?php echo e($energies2->apparent_power); ?></p>
                                            <p>Node 2</p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
                    
                
            </section>
            <?php endif; ?>
            
            <!-- Hidden section for chart canvas -->
            <section hidden>
                <div class="container-fluid">
                    <canvas id="salesBarChart1"></canvas>
                    <canvas id="salesBarChart2"></canvas>
                    <canvas id="pieChartHome1"></canvas>
                    <canvas id="pieChartHome2"></canvas>
                    <canvas id="pieChartHome3"></canvas>
                    <canvas id="barChartExample1"></canvas>
                    <canvas id="barChartExample2"></canvas>
                    <canvas id="lineChart"></canvas>
                    <canvas id="lineChart1"></canvas>
                </div>
            </section>


            <!-- Hidden section for chart canvas -->
            <section hidden>
                <div class="container-fluid">
                <canvas id="salesBarChart1"></canvas>
                    <canvas id="salesBarChart2"></canvas>
                    <canvas id="pieChartHome1"></canvas>
                    <canvas id="pieChartHome2"></canvas>
                    <canvas id="pieChartHome3"></canvas>
                    <canvas id="barChartExample1"></canvas>
                    <canvas id="barChartExample2"></canvas>
                    <canvas id="lineChart"></canvas>
                    <canvas id="lineChart1"></canvas>
                </div>
            </section>
        </div>
    </div>
    
    <script>
        // ------------------------------------------------------- //
        //   Inject SVG Sprite - 
        //   see more here 
        //   https://css-tricks.com/ajaxing-svg-sprite/
        // ------------------------------------------------------ //
        function injectSvgSprite(path) {

            var ajax = new XMLHttpRequest();
            ajax.open("GET", path, true);
            ajax.send();
            ajax.onload = function (e) {
                var div = document.createElement("div");
                div.className = 'd-none';
                div.innerHTML = ajax.responseText;
                document.body.insertBefore(div, document.body.childNodes[0]);
            }
        }
        // this is set to BootstrapTemple website as you cannot 
        // inject local SVG sprite (using only 'icons/orion-svg-sprite.svg' path)
        // while using file:// protocol
        // pls don't forget to change to your domain :)
        injectSvgSprite('https://bootstraptemple.com/files/icons/orion-svg-sprite.svg');

    </script>
    <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</body>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/energy/monitor.blade.php ENDPATH**/ ?>