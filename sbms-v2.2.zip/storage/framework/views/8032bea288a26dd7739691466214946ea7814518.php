
<?php $__env->startSection('content'); ?>

 

<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Edit Profile</h2>
      </div>
    </div>
  <div class="container-fluid">

            <section class="pt-3 mt-3">
                <div class="col-lg-12">
                    <div class="card">
                      <div class="card-header">
                        <a href="<?php echo e(url('profile')); ?>">
                            <button class="btn btn-info" >
                                Kembali
                            </button>
                        </a>
                      </div>
                      <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>
                      <div class="card-body pt-0">
                        <?php $__currentLoopData = $edituser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form class="form-horizontal" id="formEditUser" name="formEditUser" method="POST" action="<?php echo e(route('updateprofile')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($eu->id); ?>">
                            <div class="form-group mb-3">
                                <label for="name-edit" class="col-dm-6 control-label">Name</label>
                                <div class="col-center">
                                    <input type="text" id="name-edit" name="name-edit"  value="<?php echo e($eu->name); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="form-group mb-3">
                              <label for="username" class="col-dm-6 control-label">Username</label>
                              <div class="col-center">
                                  <input type="text" id="username-edit" name="username-edit" value="<?php echo e($eu->username); ?>" class="form-control">
                              </div>
                          </div>
                          
                            <div class="form-group mb-3">
                                <label for="email-edit" class="col-dm-6 control-label">Email</label>
                                <div class="col-center">
                                    <input type="email" id="email-edit" name="email-edit" value="<?php echo e($eu->email); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="form-group mb-3">
                                <div class="col text-right">
                                    <button type="submit" class="btn btn-primary" name="action">
                                        Update Profile
                                    </button>
                                </div>
                            </div>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
           
            
        </div>
    </div>
<?php $__env->stopSection(); ?>







  
<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/auth/updateprofile.blade.php ENDPATH**/ ?>