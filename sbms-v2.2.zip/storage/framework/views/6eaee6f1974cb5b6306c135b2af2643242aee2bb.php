
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Humidity</h2>
      </div>
    </div>
  <div class="container-fluid">
            <section class="pt-3 mt-3">
                <div class="container-fluid">
                    <div class="row d-flex align-items-stretch gy-4">
                        <div class="col-lg">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                    <div class="row d-flex justify-content-center pt-3">
                                        
                                        
                                        <h3 class="h4 mb-3 text">Kelembaban</h3>
                                        <?php $__empty_1 = true; $__currentLoopData = $humidity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="row align-items-end">
                                            <div class="col-lg-5">
                                                <p class="text-xl fw-light mb-0 text-dash-color-3"><?php echo e($item->humidity); ?></p><span>
                                            
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <section class="pt-0 mt-0">
                <div class="container-fluid">
                    <div class="row d-flex align-items-stretch gy-4">
                        <div class="col-lg">
                            <!-- Sales bar chart-->
                            <div class="card">
                                <div class="card-body">
                                  
                                    <div id="stockChartContainer" style="height: 400px; width: 100%;"></div>
                                    <div class="mt-3">
                                        <a class="btn btn-success " href="dhtsensorexporthumidxlxs">Export xlxs</a>
                                        <a class="btn btn-info " href="dhtsensorexporthumidcsv">Export csv</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php $__currentLoopData = $dhtx1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dhtx1s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($dhtx1s->status == 1): ?>
            <section class="pt-0 mt-0">
              <div class="container-fluid">
                  <div class="row d-flex align-items-stretch gy-4">
                      <div class="col-lg">
                          <!-- Sales bar chart-->
                          <div class="card">
                              <div class="card-body">
                                  <div class="row d-flex justify-content-center pt-3">
                                      <h3 class="h4 mb-3 ">Suhu <?php echo e($dhtx1s->nama); ?></h3>
                                      <?php $__empty_1 = true; $__currentLoopData = $tempx1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tempx1s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <div class="row align-items-end">
                                          <div class="col-lg-5">
                                              <p class="text-xl fw-light mb-0 text-dash-color-3"><?php echo e($tempx1s->humidity); ?></p><span>
                                          </div>
                                      </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                            
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $dhtx2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dhtx2s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($dhtx2s->status == 1): ?>
            <section class="pt-0 mt-0">
              <div class="container-fluid">
                  <div class="row d-flex align-items-stretch gy-4">
                      <div class="col-lg">
                          <!-- Sales bar chart-->
                          <div class="card">
                              <div class="card-body">
                                  <div class="row d-flex justify-content-center pt-3">
                                      <h3 class="h4 mb-3 ">Suhu <?php echo e($dhtx2s->nama); ?></h3>
                                      <?php $__empty_1 = true; $__currentLoopData = $tempx2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tempx2s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <div class="row align-items-end">
                                          <div class="col-lg-5">
                                              <p class="text-xl fw-light mb-0 text-dash-color-3"><?php echo e($tempx2s->humidity); ?></p><span>
                                          </div>
                                      </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                            
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $dhtx3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dhtx3s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($dhtx3s->status == 1): ?>
            <section class="pt-0 mt-0">
              <div class="container-fluid">
                  <div class="row d-flex align-items-stretch gy-4">
                      <div class="col-lg">
                          <!-- Sales bar chart-->
                          <div class="card">
                              <div class="card-body">
                                  <div class="row d-flex justify-content-center pt-3">
                                      <h3 class="h4 mb-3 ">Suhu <?php echo e($dhtx3s->nama); ?></h3>
                                      <?php $__empty_1 = true; $__currentLoopData = $tempx3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tempx3s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <div class="row align-items-end">
                                          <div class="col-lg-5">
                                              <p class="text-xl fw-light mb-0 text-dash-color-3"><?php echo e($tempx3s->humidity); ?></p><span>
                                          </div>
                                      </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                            
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $dhtx4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dhtx4s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($dhtx4s->status == 1): ?>
            <section class="pt-0 mt-0">
              <div class="container-fluid">
                  <div class="row d-flex align-items-stretch gy-4">
                      <div class="col-lg">
                          <!-- Sales bar chart-->
                          <div class="card">
                              <div class="card-body">
                                  <div class="row d-flex justify-content-center pt-3">
                                      <h3 class="h4 mb-3 ">Suhu <?php echo e($dhtx4s->nama); ?></h3>
                                      <?php $__empty_1 = true; $__currentLoopData = $tempx4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tempx4s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <div class="row align-items-end">
                                          <div class="col-lg-5">
                                              <p class="text-xl fw-light mb-0 text-dash-color-3"><?php echo e($tempx4s->humidity); ?></p><span>
                                          </div>
                                      </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                            
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $dhtx5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dhtx5s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($dhtx5s->status == 1): ?>
            <section class="pt-0 mt-0">
              <div class="container-fluid">
                  <div class="row d-flex align-items-stretch gy-4">
                      <div class="col-lg">
                          <!-- Sales bar chart-->
                          <div class="card">
                              <div class="card-body">
                                  <div class="row d-flex justify-content-center pt-3">
                                      <h3 class="h4 mb-3 ">Suhu <?php echo e($dhtx5s->nama); ?></h3>
                                      <?php $__empty_1 = true; $__currentLoopData = $tempx5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tempx5s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                      <div class="row align-items-end">
                                          <div class="col-lg-5">
                                              <p class="text-xl fw-light mb-0 text-dash-color-3"><?php echo e($tempx5s->humidity); ?></p><span>
                                          </div>
                                      </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                                            
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
    
    <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

        <script type="text/javascript" src="<?php echo e(asset('js/linechartcanvas.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/linechartcanvasjquery.js')); ?>"></script>
        <script type="text/javascript">
        window.onload = function () {
          var dataPoints = [];
          var stockChart = new CanvasJS.StockChart("stockChartContainer",{
            theme: "dark2", //"light1", "dark1", "dark2" "light2",
            exportEnabled: true,
            title:{
              text:"Humidity"
            },
            charts: [{
              axisX: {
                crosshair: {
                  enabled: true,
                  //snapToDataPoint: true
                  valueFormatString: "MMM DD, YYYY HH:mm:ss"
                }
              },
              axisY: {
                prefix: "",
                crosshair: {
                  enabled: true,
                  snapToDataPoint: true,
                  valueFormatString: "##"
                }
              },
              toolTip: {
                shared: true
              },
              data: [{
                type: "area",
                name: "Kelembaban",
                yValueFormatString: "## ",
                xValueFormatString: "MMM DD, YYYY HH:mm:ss",
                xValueType: "dateTime",
                dataPoints : dataPoints
              }]
            }],
            navigator: {
              slider: {
              
              }
            }
          });
            
               $.getJSON("api/humidlogger", function(data) {
                 for(var i = 0; i < data.length; i++){
                   dataPoints.push({x: new Date(data[i].date), y: Number(data[i].sale)});
                 }
                 stockChart.render();
               });
             }
             </script>
            <script type="text/javascript">
                function autoRefreshPage()
                {
                    window.location = window.location.href;
                }
                setInterval('autoRefreshPage()', 300000);
            </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/environment/humidity.blade.php ENDPATH**/ ?>