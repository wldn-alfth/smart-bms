<!DOCTYPE html>
<html>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 'Admin' || Auth::user()->level == 'Developer'): ?>
  
<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Daftar Hak Akses</h2>
      </div>
    </div>
  <div class="container-fluid">
    <?php if(Auth::user()->level == 'Developer'): ?>
    <section class="pt-3 mt-3">
      <div class="container-fluid">
          <div class="row d-flex align-items-stretch">
              <div class="col-lg">
                  <!-- Sales bar chart-->
                  <div class="card">
                      <div class="card-body">
                        <h3>Daftar Developer</h3>
                        <div class="d-flex justify-content-end">
                            <a class="btn btn-success" href="daftar-admin-create">Tambah</a>
                        </div>
                          <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                              
                              </div>
                      
                          <?php if($message = Session::get('succes')): ?>
                          <div class="alert alert-success">
                              <p><?php echo e($message); ?></p>
                          </div>
                          <?php endif; ?>
                      
                          <table class="table table-bordered">
                              <tr>
                                  <th class="text-center">No</th>
                                  <th class="text-center">Nama</th>
                                  <th class="text-center">Username</th>
                                  <th class="text-center">Level</th>
                                  <th class="text-center">Email</th>
                                  <th class="text-center" width="140px">Action</th>
                              </tr>
                              <?php $__currentLoopData = $developer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td class="text-center"><?php echo e(++$i); ?></td>
                                  <td><?php echo e($dev->name); ?></td>
                                  <td><?php echo e($dev->username); ?></td>
                                  <td><?php echo e($dev->level); ?></td>
                                  <td><?php echo e($dev->email); ?></td>
                                  <td class="text-center">
                                    
                                          <a class="btn btn-primary btn-sm" href="daftar-admin-edit/<?php echo e($dev->id); ?>">Edit</a>
                                          <a href="deleteUser/<?php echo e($dev->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                          
                                  </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                      
                          <?php echo e($developer->links()); ?>


                          </div>
                      </div>
                  </div>
              </div>
          </div>
      
  </section>


  <?php endif; ?>

      <section class="pt-3 mt-3">
            <div class="container-fluid">
                <div class="row d-flex align-items-stretch">
                    <div class="col-lg">
                        <!-- Sales bar chart-->
                        <div class="card">
                            <div class="card-body">
                              <h3>Daftar Admin</h3>
                              <div class="d-flex justify-content-end">
                                  <a class="btn btn-success" href="daftar-admin-create">Tambah</a>
                              </div>
                                <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                    
                                    </div>
                            
                                <?php if($message = Session::get('succes')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e($message); ?></p>
                                </div>
                                <?php endif; ?>
                            
                                <table class="table table-bordered">
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th class="text-center">Nama</th>
                                        <th class="text-center">Username</th>
                                        <th class="text-center">Level</th>
                                        <th class="text-center">Email</th>
                                        <th class="text-center" width="140px">Action</th>
                                    </tr>
                                    <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e(++$j); ?></td>
                                        <td><?php echo e($admins->name); ?></td>
                                        <td><?php echo e($admins->username); ?></td>
                                        <td><?php echo e($admins->level); ?></td>
                                        <td><?php echo e($admins->email); ?></td>
                                        <td class="text-center">
                                          
                                                <a class="btn btn-primary btn-sm" href="daftar-admin-edit/<?php echo e($admins->id); ?>">Edit</a>
                                                <a href="deleteUser/<?php echo e($admins->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                                
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            
                                <?php echo e($admin->links()); ?>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>

        <section class="pt-3 mt-3">
          <div class="container-fluid">
              <div class="row d-flex align-items-stretch gy-4">
                  <div class="col-lg">
                      <!-- Sales bar chart-->
                      <div class="card">
                          <div class="card-body">
                            <h3>Daftar User</h3>
                            <div class="d-flex justify-content-end">
                                <a class="btn btn-success" href="daftar-admin-create">Tambah</a>
                            </div>
                              <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                  
                                  </div>
                          
                              <?php if($message = Session::get('succes')): ?>
                              <div class="alert alert-success">
                                  <p><?php echo e($message); ?></p>
                              </div>
                              <?php endif; ?>
                          
                              <table class="table table-bordered">
                                  <tr>
                                      <th class="text-center">No</th>
                                      <th class="text-center">Nama</th>
                                      <th class="text-center">Username</th>
                                      <th class="text-center">Level</th>
                                      <th class="text-center">Email</th>
                                      <th class="text-center" width="140px">Action</th>
                                  </tr>
                                  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td class="text-center"><?php echo e(++$k); ?></td>
                                      <td><?php echo e($userr->name); ?></td>
                                      <td><?php echo e($userr->username); ?></td>
                                      <td><?php echo e($userr->level); ?></td>
                                      <td><?php echo e($userr->email); ?></td>
                                      <td class="text-center">
                                        
                                              <a class="btn btn-primary btn-sm" href="daftar-admin-edit/<?php echo e($userr->id); ?>">Edit</a>
                                              <a href="deleteUser/<?php echo e($userr->id); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm">Delete</a>
                                              
                                      </td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </table>
                          
                              <?php echo e($user->links()); ?>


                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          
      </section>
        
    </div>
</div>

<?php else: ?>
<div class="page-content">
    <!-- Page Header-->
    <div class="bg-dash-dark-1 py-4">
      <div class="container-fluid">
        <h2 class="h5 mb-0">Akses Ditolak</h2>
      </div>
    </div>
  <div class="container-fluid">
        <section class="pt-3 mt-3">
                    <div class="container-fluid">
                        <div class="row d-flex align-items-stretch">
                            <div class="col-lg">
                                <!-- Sales bar chart-->
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex align-items-end justify-content-between pt-2 pb-2">
                                            <h3 class="h4 mb-3 text-white">Akses Menuju Laman Ditolak</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </section>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sbms\sbms\resources\views/admin/list.blade.php ENDPATH**/ ?>