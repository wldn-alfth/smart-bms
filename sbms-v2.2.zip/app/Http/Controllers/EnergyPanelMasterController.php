<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EnergyPanelMasterController extends Controller
{
    //cek di EnergiOutletController
}
