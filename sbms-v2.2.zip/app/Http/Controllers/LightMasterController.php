<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LightMasterController extends Controller
{
    //cek di LightControlController
}
