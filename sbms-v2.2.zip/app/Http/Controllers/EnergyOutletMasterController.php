<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EnergyOutletMasterController extends Controller
{
    ////cek di EnergiOutletController
}
