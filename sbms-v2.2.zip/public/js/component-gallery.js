"use strict";

document.addEventListener("DOMContentLoaded", function () {
    const lightbox = GLightbox({
        touchNavigation: true,
    });
});
